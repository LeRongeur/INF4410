package ca.polymtl.inf4410.tp1.client;

public class FakeServer {
	int execute(int a, int b) {
		return a + b;
	}
	void fonctionVide(byte[] table)
	{
	
	}
}
